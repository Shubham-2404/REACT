import React from "react";

function Note() {
  return (
    <div>
      <h1>Javascript And REact.js</h1>
    <p>ITs Shape ai BOOTCAMP.</p>
    </div>
  );
}

export default Note;
