import React from "react";

function Footer() {
 
  var currYear = new Date().getFullYear();

  return (
    <footer>
      <p>COPYRIGHTS @ 2021</p>
    </footer>
  );
}

export default Footer;
